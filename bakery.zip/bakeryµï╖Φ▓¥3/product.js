document.addEventListener('DOMContentLoaded', () => {
    const productImages = document.querySelectorAll(".product-images img");
    const productImagesSlide = document.createElement(".image-slider");
    
    let activeImageSlide = 0;
    
    productImages.forEach((item, i) => {
        item,activeImageSlide('click', () => {
            productImages[activeImageSlide].classList.remove('active');
            item.classList.add('active');
            productImagesSlide.style.backgroundImage = `url('${item.src}')`;
            activeImageSlide = i;
        });
    });

// toggle flavors buttons
    const flavorsBtns = document.querySelectorAll('.flavors-radio-btn');
    let checkedBtn = 0;

    flavorsBtns.forEach((item, i) => {
        item.addEventListener('click', () => {
            flavorsBtns[checkedBtn].classList.remove('check');
            item.classList.add('check');
            checkedBtn = i;
        })
    })

    const setData = (data) => {
        let title = document.querySelector('title');
        title.innerHTML += data.name;

    //setup the images
    productImages.forEach((img, i) => {
        if (data.images[i]){
            img.src = data.images[i];
        } else{
            img.style.display = 'none';
        }
    });
    productImages[0].click();

    //set flavors buttons
    flavorsBtns.forEach(item => {
        if(!data.flavors.includes(item.innerHTML)){
            item.style.display = 'none';
        }
    });

    //setting up texts
    const name = document.querySelector('.product-brand');
    const short = document.querySelector('.product-short-des');
    const des = document.querySelector('.des');

    title.innerHTML += name.innerHTML = data.name;
    short.innerHTML = data.shortDes;
    des.innerHTML = data.des;

    //pricing
    const sellPrice = document.querySelector('.product-price');
    sellPrice.innerHTML = `$${data.sellPrice}`;
    };


// fetch data
const fetchProductData = () => {
    fetch('/get-products',{
        method:'post',
        headers: new Headers({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({id: productId}),
    })
    .then(res => res.json())
    .then(data => {
        setData(data);
        getProducts(data.tags[1]).then(data => createProductSlider(data,''))
    })
};

let productId = null;
if(location.pathname != '/products'){
    productId = decodeURI(location.pathname.split('/').pop());
    fetchProductData();
}

    const addToCartButtons = document.querySelectorAll(".cart-btn");
    const cartItemElement = document.querySelector(".cart-items");
    const cartTotalElement = document.querySelector('.cart-total');
    let cart = []

    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const productId = button.getAttribute('data-product-id');
            const productName = button.parentElement.querySelector('p').innerText;
            const productPrice = parseFloat(button.parentElement.querySelector('h2'),innerText);

            addToCart(productId, productName, productPrice);
            updateCartUI();
        });
    });

    function addToCart(productId, productName, productPrice){
        const existingProduct = cartfind(item => item.id === productId);

        if (existingProduct){
            existingProduct.quantity += 1;
        } else{
            cart.push({ id: productId, name: productName, price: productPrice, quantity:1 });
        }
    }

    function updateCartUI(){
        cartItemList.innerHTML = '';
        let total = 0;

        cart.forEach(item => {
            const cartItemElement = document.createElement('li');
            cartItemElement.innerText = `${item.name} - NT$${item.price} x ${item.quantity}`;
            cartItemList.appendChild(cartItemElement);

            total += item.price * item.quantity;
        });

            cartTotalElement.innerText = `NT$${total.toFixed(2)}`;
    }
});


    /*productImages.forEach((item, i) => {
        item.addEventListener('click', () => {
            productImages[activeImageSlide].classList.remove('active');
            item.classList.add('active');
            productImagesSlide.style.backgroundImage = `url('${item.src}')`;
            activeImageSlide = i;
        });
    });

    const flavorsBtns = document.querySelectorAll('.flavors-radio-btn');
    const shortDes = document.querySelector('.short-des');
    const des = document.querySelector('.des');
    const wishlistBtn = document.querySelector('.wishlist-btn');
    let checkedBtn = 0;
    let flavors;

    flavorsBtns.forEach((item, i) => {
        item.addEventListener('click', () => {
            flavorsBtns[checkedBtn].classList.remove('check');
            item.classList.add('check');
            checkedBtn = i;
            flavors = item.innerHTML;
        });
    });

    const setData = (data) => {
        let title = document.querySelector('title');

        productImages.forEach((img, i) => {
            if (data.images[i]) {
                img.src = data.images[i];
            } else {
                img.style.display = 'none';
            }
        });
        productImages[0].click();

        flavorsBtns.forEach(item => {
            if (!data.flavors.includes(item.innerHTML)) {
                item.style.display = 'none';
            }
        });

        const name = document.querySelector('.product-brand');

        title.innerHTML += name.innerHTML = data.name;
        shortDes.innerHTML = data.shortDes;
        des.innerHTML = data.des;

        const sellPrice = document.querySelector('.product-price');

        sellPrice.innerHTML = `$${data.sellPrice}`;

        // cart btn
        const cartBtn = document.querySelector('.cart-btn');
        cartBtn.addEventListener('click', () => {
            cartBtn.innerHTML = add_product_to_cart('cart', data);
        });
    };

    const fetchProductData = () => {
        fetch('/get-products', {
            method: 'post',
            headers: new Headers({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ id: productId })
        })
        .then(res => res.json())
        .then(data => {
            setData(data);
            getProducts(data.tags[1]).then(data => createProductSlider(data, '.container-for-card-slider', 'similar product'));
        })
        .catch(err => {
            location.replace('/404');
        });
    };

    let product = null;
    if (location.pathname != '/products') {
        product = decodeURI(location.pathname.split('/').pop());
        fetchProductData();
    }

    // Shopping cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    const cartItemsList = document.querySelector('.cart-items');
    const cartTotalElement = document.querySelector('.cart-total');
    let cart = [];

    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const productId = button.getAttribute('data-product-id');
            const productName = button.parentElement.querySelector('h2').innerText;
            const productPrice = parseFloat(button.parentElement.querySelector('.product-price').innerText);

            addToCart(productId, productName, productPrice);
            updateCartUI();
        });
    });

    function addToCart(productId, productName, productPrice) {
        const existingProduct = cart.find(item => item.id === productId);

        if (existingProduct) {
            existingProduct.quantity += 1;
        } else {
            cart.push({ id: productId, name: productName, price: productPrice, quantity: 1 });
        }
    }

    function updateCartUI() {
        cartItemsList.innerHTML = '';
        let total = 0;

        cart.forEach(item => {
            const cartItemElement = document.createElement('li');
            cartItemElement.innerText = `${item.name} - $${item.price} x ${item.quantity}`;
            cartItemsList.appendChild(cartItemElement);

            total += item.price * item.quantity;
        });

        cartTotalElement.innerText = `NT$${total.toFixed(2)}`;
    }
}); */