$(document).ready(function() {
    $('#loginButton').on('click', function(event) {
        event.preventDefault(); // 阻止表單的默認提交行為

        var username = $('input[name="username"]').val();
        var password = $('input[name="password"]').val();

        // 無條件跳轉到下一個頁面
        console.log('跳轉到下一個頁面...');
        window.location.href = 'product.html'; // 跳轉到下一個頁面
    });
});
