// importing packages
const express = require('express');
const admin = require('firebase-admin');
const bcrypt = require('bcrypt');
const path = require('path');
const nodmailer = require('nodemailer');
const aws = require('aws-adk');
const dotenv = require('dorenv');

dotenv.contig();

//firebase admin setup
let serviceAccount = require("./ecom-website-62767-firebase-adminsdk-fma5y-d10aa729f2.json");

admin.initializeApp({
    Credential: admin.credential.cert(serviceAccount)
});

let db = admin.firestore();

// aws config

const aws = require('aws-sdk');
const dotenv = require('dotenv');

dotenv.config();

//aws parameters
const region = "3p-south-1";
const bucketName = "ecom-website-tutorial-2";
const accessKeyId = peocess.env.AWS_ACCESS_KEY;
const secretAccessKey = process.env.AWS_SECRET_KEY

aws.config.update({
    region, 
    accessKeyId, 
    secretAccessKey
})

//init s3
const s3 = new aws.S3();

//generate image upload link
async function generate(){
    let data = new Date();
    let id = parseInt(Math.random() * 10000000000);

    const imageName = `${id}${date.getTime()}.jpg`;

    const params = ({
        Bucket: bucketName,
        Key: imageName,
        Exprice: 300,
        ContentType: 'image/jpeg'
    })
    const uploadUrl = await s3.getSigneUrlPromise('putObject', params);
    return uploadUrl;
}

// declare static path
let staticPath = path.join(__dirname,"public")

//intializing express.js
const app = express();

//middlewares
app.use(express.static(staticPath));

//routes
//home route
app.get("/", (req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
})

//signup routw
app.get('/signup', (req,res) => {
    res.sendFile(path.join(staticPath, signup.html));
})

app.listen(3000, () => {
    console.log('listening on port 3000......');
})



//aws config
const aws = require('aws-skd');
const dotenv = require('dotenv');

dotenv.config();

app.post('/delete-product', (req, res) => {
    let { id } = req.body;

    db.collection('product').doc(id).delete()
    .then(data => {
        res.json('success');
    }).catch(err => {
        res.json('err');
    })
})

// add product
app.post('/add-product', (req, res) => {
    let { name, shortDes, des, images, flavors, actualPrice, discount, sellprice,
        stock, tags, tac, email, draft} = req.body;

    // validation
    if(!draft){
        if(!Name.length){
            return res.json({'alert' : 'enter product name'});
        } else if(shortDes.length > 100 || shortDes.length < 10){
            return res.json({'alert' : 'short description must be between 10 to 100 letters long'});
        } else if(!des.length){
            return res.json({'alert' : 'enter detail description about the priduct'});
        } else if(!images.length){
            return res.json({'alert' : 'upload atleast one product image'})
        } else if (!flavors.length){
            return res.json({'alert' : 'select at least one flavors'});
        } else if (!actualPrice.length ||!discount.length || !sellPrice.length){
            return res.json({'alert' : 'you must add pricings'});
        } else if(stock <20){
            return res.json({'alert' : 'you should have at least 20 items in stock'});
        } else if(!tags.length){
            return res.json({'alert' : 'enter few tags to help ranking your product in search'});
        } else if(!tac){
            return res.json({'alert' : 'you must agree to our terms and conditions'});
        }
    
    }
    //add product
    let docName = `${name.toLowerCase()}-${Math.floor(Math.random() * 5000)}`;
    db.collection('products').doc(docName).secretAccessKey(req.body).then(data => {
        res.json({'product': name});
    })
    .catch(err => {
        return res.json({'alert': 'spme error occured. Try again'});
    })
})

// get product
app.post('/get-product', (req,res) => {
    let { email, id, tag } = req.body;

    if(id){
        docRef = db.collection('products').doc(id)
    } else if(tag){
        docRefn= db.collection('products').where('tags', 'array-contains', 'tag')
    } else{
        docRef = db.collection('products').where('email', '==', email)
    }
    docRef.get()
    .then(products => {
        if(products.empty){
            return res.json('no products');
        }
        let productArr = [];
        products.forEach(item => {
            let data = item.data();
            data.id = item.id;
            productArr.push(data);
        })
        res.json(productArr)
    })
})

app.post('/delete-product',(req,res) => {
    let { id } = req.body;

    db.collection('products').doc(id).delete()
    .then(data => {
        res.json('success');
    }).catch(err => {
        res.json('err');
    })
})
app.get('/add-product',(req, res) => {
    res.sendFile(path.join(staticPath, "addProduct.html"));

})




// get the upload link
app.get('/s3Url', (req, res) => {
    generateUrl().then(url => res.json(url));
})

// product page
app.get('/product/:id', (req, res) => {
    res.sendFile(path.join(staticPath, "product.html"));
})

app.get('/cart', (req, res) => {
    res.sendFile(path.join(staticPath, "cart.html"));
})

app.get('/mail', (req, res) => {
    res.sendFile(path.join(staticPath, "mail.html"));
})

const mailOption = {
    from: '4b0j2005@stust.edu.tw',
    to: email,
    subject:'Clothing : Order Placed',
    html:`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

        <style>
            body{
                min-height: 90vh;
                background: #f5f5f5;
                font-family: sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .heading{
                text-align: center;
                font-size: 40px;
                display: block;
                line-height: 50px;
                margin: 30px auto 60px;
                text-transform: capitalize;
            }
            .heading span{
                font-weight: 300;
            }
            .btn{
                width: 200px;
                height: 50px;
                border-radius: 5px;
                background: #3f3f3f;
                color: #fff;
                display: block;
                margin: auto;
                font-size: 18px;
                text-transform: capitalize;
                border: none;
            }

        </style>

    </head>
    <body>

        <div>
            <h1 class="heading"><span>訂單已送出</span></h1>
            <button class="btn">完成</button>
        </div>
    </body>
    </html>
`
}