document.addEventListener('DOMContentLoaded', () => {
const flavorsBtns = document.querySelectorAll('.flavors-radio-btn');
let checkedBtn = 0;
let flavors;
 

flavorsBtns.forEach((item, i) => {
    item.addEventListener('click', () => {
        flavorsBtns[checkedBtn].classList.remove('check');
        item.classList.add('check');
        checkedBtn = i;
        flavors = item.innerHTML;
    })
    
})

const setData = (data) => {
    let title = document.querySelector('title');

    flavorsBtns.forEach(item => {
        if(!data.flavors.includes(item.innerHTML)){
            item.style.display = 'none';
        }
    })
}
$(document).on('click', '.buybtn', function() {
    $(this).text("已加入購物車");
    $(this).addClass("buyed");
});

})


/*flavorsBtns.forEach((item, i) => {
    item.addEventListener('click', () => {
        flavorsBtns[checkedBtn].classList.remove('check');
        item.classList.add('check');
        checkedBtn = i;
        flavors = item.innerHTML;
    });
    
});

const setData = (data) => {
    let title = document.querySelector('title');

    flavorsBtns.forEach(item => {
        if(!data.flavors.includes(item.innerHTML)){
            item.computedStyleMap.display = 'none';
        }
    })

    $(".buybtn").click(
        function(){
          $(this).text("已加入購物車");     
          $(this).addClass("buyed");
        });
});

/*let data = JSON.parse(localStorage.getItem(type));
    if(data = null){
        data = [];
    }

    product = {
        item: 1,
        name:product.name,
        flavors: flavors || null
    }
}

document.querySelectorAll('.buybtn').forEach(function(button) {
    button.addEventListener('click', function() {
      this.textContent = "已經購買";
      this.classList.add("buyed");
    });
  });

const cartBtn = document.querySelector('cart-btn');
cartBtn.addEventListener('click', () => {
    cartBtn.innerHTML = add_product_to_cart('cart', data);
}) */