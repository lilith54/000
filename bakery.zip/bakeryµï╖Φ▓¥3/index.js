let slides = document.querySelectorAll('#slider .slide');
let currentSlide = 0;
let prevButton = document.getElementById('prev');
let nextButton = document.getElementById('next');

function showSlide(n) {
  slides[currentSlide].style.opacity = 0;
  currentSlide = (n+slides.length)%slides.length;
  slides[currentSlide].style.opacity = 1;
}

prevButton.addEventListener('click', function() {
  showSlide(currentSlide - 1);
});

nextButton.addEventListener('click', function() {
  showSlide(currentSlide + 1);
});

showSlide(currentSlide); // Show the first slide
