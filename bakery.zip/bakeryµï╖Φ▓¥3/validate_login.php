<?php
// 示例数据，实际情况中你会从数据库中获取用户数据
$valid_username = '7272727';
$valid_password = '62727';

// 获取 POST 请求中的数据
$username = $_POST['username'];
$password = $_POST['password'];

// 验证用户名和密码
if ($username === $valid_username && $password === $valid_password) {
    echo 'success';
} else {
    echo 'error';
}
?>;

